# Stamply Universal Icons

This folder should contain the extension icons:

- `icon16.png` - 16x16 pixels (toolbar icon)
- `icon48.png` - 48x48 pixels (extension management page)
- `icon128.png` - 128x128 pixels (Chrome Web Store)

## Creating Icons

You can create simple icons using any image editor or use these placeholder SVGs converted to PNG:

### Icon Design Guidelines:
- Use the Stamply leaf theme 🌱
- Green/eco-friendly color scheme
- Simple, recognizable design
- High contrast for visibility

### Temporary Solution:
The manifest.json currently uses base64-encoded SVG icons as placeholders. For production, replace with proper PNG files.

### Colors:
- Primary: #4ade80 (green)
- Secondary: #22c55e (darker green)
- Accent: #059669 (forest green)
- Background: #f0fdf4 (light green)

### Example Icon Content:
- Leaf symbol (🌱)
- "S" letter for Stamply
- Earth/globe symbol (🌍)
- Combination of leaf + AI circuit pattern
