import chatgpt from './ai_providers/chatgpt.js';
import claude from './ai_providers/claude.js';
import gemini from './ai_providers/gemini.js';

export const IMPACT_MODELS = { chatgpt, claude, gemini };
export const COMPLEXITY_LEVELS = ['simple', 'medium', 'complex'];
